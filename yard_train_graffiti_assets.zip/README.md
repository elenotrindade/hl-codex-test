# Yard / Train Graffiti — pacote de assets

Arquivos em proporção 5:2, resolução de trabalho 2500×1000.

- train_base.png / .webp
- train_mask.png
- wall_base.png / .webp
- wall_mask.png
- van_base.png / .webp
- van_mask.png
- *_mask_preview.jpg
- preview_all.jpg

Máscaras:
- branco = área pintável
- preto = área protegida

Observação:
As máscaras foram preparadas como primeira versão operacional alinhada às áreas amplas e desobstruídas do brief. Antes de produção final, vale fazer um refinamento pixel a pixel nas bordas de ferragens, frisos e recortes.
